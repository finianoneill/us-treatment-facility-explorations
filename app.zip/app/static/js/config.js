// API key
const API_KEY = "pk.eyJ1IjoiZmluaWFuZG9uZWlsbCIsImEiOiJjanAzZmRwMnQwaGZ2M2tvYm5nNGNqcmE4In0.XAVtWcAaSFjXYCZRxkA6iw";
